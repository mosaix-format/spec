Mosaix example vault - the specification itself as a conformant vault.
Open the folder in Obsidian or any Markdown editor; start from Home.md.
Check it: python audit_reference.py mosaix-example-vault
Includes a minimal .obsidian/ folder (graph colours by note type, wikilinks on). Delete it if you use another editor: nothing in the vault depends on it.
https://mosaixformat.org - CC BY-SA 4.0
