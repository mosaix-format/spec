---
title: Mosaix for a new team
id: 01JVKE4X2PHBDF5NV2RJWQCK4G
type: document
updated: 2026-09-03
tags: [composed-document, onboarding]
status: sourced
summary: "Composed document for someone joining a team that uses Mosaix: purpose, the note, two commitments plus agent recommendation R8, and what is out of scope, assembled from six notes without copying them."
keywords: [onboarding, new team member, composed document example, read in ten minutes, fragments, assembled, document]
entities:
  - {name: Mosaix Format, type: project}
relations: []
links: [§1 Purpose, §3 The note, "R6 Record, don't resolve", "R7 Supersede, don't delete", "R8 Propose, don't apply", §8 Out of scope]
fragments: [§1 Purpose, §3 The note, "R6 Record, don't resolve", "R7 Supersede, don't delete", "R8 Propose, don't apply", §8 Out of scope]
rev: 2233bbcc44dd
---

# Mosaix for a new team

Read the six fragments in order. The document is only the view; each fragment stays its own note.
