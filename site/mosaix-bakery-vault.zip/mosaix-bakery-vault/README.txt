Mosaix example vault — Forno Vialetto, a fictional artisan bakery.
Open the folder in Obsidian or any Markdown editor; start from Home.md.
Check it: python audit_reference.py mosaix-bakery-vault
Everything in this vault is invented. CC BY-SA 4.0.
https://mosaixformat.org
